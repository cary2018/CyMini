-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : tp6
-- 
-- Target Server Type : MYSQL
-- Date : 2024-06-26 21:53:48
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `cy_album`
-- -----------------------------
DROP TABLE IF EXISTS `cy_album`;
CREATE TABLE `cy_album` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0' COMMENT '相册分类',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `title` varchar(60) NOT NULL DEFAULT '' COMMENT '标题',
  `remarks` varchar(200) NOT NULL DEFAULT '' COMMENT '备注',
  `img` varchar(120) NOT NULL DEFAULT '' COMMENT '原图片',
  `thumbImg` varchar(120) NOT NULL DEFAULT '' COMMENT '缩略图片',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `createTime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cy_album`
-- -----------------------------
-- -----------------------------
-- Records of `cy_album`
-- -----------------------------
INSERT INTO `cy_album` VALUES (68,2,0,'风景','','uploads/img/20230527/f1b67aa68718362a01d7eacfbf0e4000.jpg','uploads/thumb/20230527/2f86ca08abf486da88f329e6cb5a09a9.jpg',1,1685199596);
INSERT INTO `cy_album` VALUES (61,2,0,'风景','','uploads/img/20230527/41a73a5e14352e4c556334491935f236.jpg','uploads/thumb/20230527/a7146b8efa64ba14c2266d34731d34e3.jpg',1,1685199594);
INSERT INTO `cy_album` VALUES (62,2,0,'风景','','uploads/img/20230527/ab2f4491cd12c45f2714605d9c558854.jpg','uploads/thumb/20230527/8c53d638e194670c7ba0c15521963c1c.jpg',1,1685199594);
INSERT INTO `cy_album` VALUES (63,2,0,'风景','','uploads/img/20230527/4260c6b0e80c227ba6422b738e0d7ee7.jpg','uploads/thumb/20230527/3576e0912cdd83341f5907e5ecdd8c96.jpg',1,1685199595);
INSERT INTO `cy_album` VALUES (67,2,0,'风景','','uploads/img/20230527/cb3d003147da80ce434dc1b548026a05.jpg','uploads/thumb/20230527/97a625abad0df1dbc38c26d199a425e3.jpg',1,1685199596);
INSERT INTO `cy_album` VALUES (64,2,0,'风景','','uploads/img/20230527/5124a4cfe604b1e3b3594b5903e4d8b0.jpg','uploads/thumb/20230527/bcb8ddc159c89ab2c13cace7c8f88308.jpg',1,1685199595);
INSERT INTO `cy_album` VALUES (65,2,0,'风景','','uploads/img/20230527/bb1da24f554250b80d08826fa7ca7c16.jpg','uploads/thumb/20230527/4fb4439e12c3d618025e898bf5c9bf58.jpg',1,1685199595);
INSERT INTO `cy_album` VALUES (66,2,0,'风景','','uploads/img/20230527/40b8f48b212f7fe28a6c59662f823d7d.jpg','uploads/thumb/20230527/7d53cdaf529a1af2ff36f5fd3a6a7e0b.jpg',1,1685199596);
INSERT INTO `cy_album` VALUES (34,1,0,'二次元','','uploads/img/20230527/60c3a9ad8f3f28fad81e1c54478721bb.jpg','uploads/thumb/20230527/277f407df8ca0ce55d5f155637b4a9fb.jpg',1,1685199316);
INSERT INTO `cy_album` VALUES (35,1,0,'二次元','','uploads/img/20230527/d1455a6dcc1339eea93ee58d53c307fb.jpg','uploads/thumb/20230527/4b11c2e0d5320df4fb2cc7d4ae0bd8c1.jpg',1,1685199316);
INSERT INTO `cy_album` VALUES (36,1,0,'二次元','','uploads/img/20230527/a4dd6506d30f202af7380c928e788863.jpg','uploads/thumb/20230527/dfd078416ff267c061277e8d426aed4f.jpg',1,1685199316);
INSERT INTO `cy_album` VALUES (37,1,0,'二次元','','uploads/img/20230527/2a0f693835098b54b145bd7612415cf9.jpg','uploads/thumb/20230527/4fea0e168ba69f34976841581dd61ece.jpg',1,1685199317);
INSERT INTO `cy_album` VALUES (38,1,0,'二次元','','uploads/img/20230527/c686bc91658e1ac6ad627ab6853d5568.jpg','uploads/thumb/20230527/1f0bc22010d98d81899261ff4f31a643.jpg',1,1685199317);
INSERT INTO `cy_album` VALUES (39,1,0,'二次元','','uploads/img/20230527/8952b6e6ee0d6282739a2fdd69132a76.jpg','uploads/thumb/20230527/ad5e1d23ef1071575814fe974439ac6d.jpg',1,1685199317);
INSERT INTO `cy_album` VALUES (40,1,0,'二次元','','uploads/img/20230527/0fb0c17bc58701c4f63212cc33b3b5c9.jpg','uploads/thumb/20230527/1eb140733bdc698530c95a8f01f4c51b.jpg',1,1685199317);
INSERT INTO `cy_album` VALUES (41,1,0,'二次元','','uploads/img/20230527/82f61c97fa28f3fc1fe47bb339090217.jpg','uploads/thumb/20230527/8abf9779feae01d6e047732081e7dff1.jpg',1,1685199317);
INSERT INTO `cy_album` VALUES (42,1,0,'二次元','','uploads/img/20230527/665d3c64acdbd763f6906acfb9734446.jpg','uploads/thumb/20230527/e081819694264f5a3c6f12d99ec5430c.jpg',1,1685199317);
INSERT INTO `cy_album` VALUES (43,1,0,'二次元','','uploads/img/20230527/7e08ab134e823d116f4111fd41d30ffb.jpg','uploads/thumb/20230527/e4e0c8758f1e2308d76defdc08bd53bf.jpg',1,1685199317);
INSERT INTO `cy_album` VALUES (44,1,0,'二次元','','uploads/img/20230527/f09e17b388cefdb7249326ebdbb379f8.jpg','uploads/thumb/20230527/ae4843253098f01d1b130b26802a4b2e.jpg',1,1685199318);
INSERT INTO `cy_album` VALUES (45,1,0,'二次元','','uploads/img/20230527/cedef280ab22ab3c74980c99d1cf9d3c.jpg','uploads/thumb/20230527/1edced1210461b2dd6adf8954d868d52.jpg',1,1685199318);
INSERT INTO `cy_album` VALUES (46,1,0,'二次元','','uploads/img/20230527/e5c535792a3c273589df9ebd67d40d8f.jpg','uploads/thumb/20230527/2c7616ec7a59b2afd04d4b7fc59453cf.jpg',1,1685199318);
INSERT INTO `cy_album` VALUES (47,1,0,'二次元','','uploads/img/20230527/ec856c513d9b8c54faa89ad90c5d2473.jpg','uploads/thumb/20230527/7e7d96f8ec935201813a8228d79ecd82.jpg',1,1685199318);
INSERT INTO `cy_album` VALUES (48,1,0,'二次元','','uploads/img/20230527/455095244e5c9622e8b56c00cbee51f1.jpg','uploads/thumb/20230527/2dfe645e455ffbb40aec96acf33f3f7d.jpg',1,1685199318);
INSERT INTO `cy_album` VALUES (49,1,0,'二次元','','uploads/img/20230527/c2b63466d04b25d11187f8d2480c8c34.jpg','uploads/thumb/20230527/32ce9726b1787be9986f97c7aadab5eb.jpg',1,1685199318);
INSERT INTO `cy_album` VALUES (50,1,0,'二次元','','uploads/img/20230527/aad9295dcc58b73b332e192b2c3f442c.jpg','uploads/thumb/20230527/b59c1166448de19fc989ebbee3dccce3.jpg',1,1685199319);
INSERT INTO `cy_album` VALUES (51,1,0,'二次元','','uploads/img/20230527/a3e258a4c6e281f45fc13a24b1d9a5f0.jpg','uploads/thumb/20230527/cbbc1312ca7bd98c178b3f39a2f13b21.jpg',1,1685199319);
INSERT INTO `cy_album` VALUES (52,1,0,'二次元','','uploads/img/20230527/dc149788e5a181959ed7fec3fdb9652f.jpg','uploads/thumb/20230527/d203975dcaaa321e2d33513f66b6bd0d.jpg',1,1685199319);
INSERT INTO `cy_album` VALUES (53,1,0,'二次元','','uploads/img/20230527/4263371b0ab53692a25622eeab7a2495.jpg','uploads/thumb/20230527/02e244764e150a05e581995608246a8b.jpg',1,1685199319);
INSERT INTO `cy_album` VALUES (54,2,0,'风景','','uploads/img/20230527/5cbfdbda9f5396086fe4bf3b9954d543.jpg','uploads/thumb/20230527/4bb34f19311ed380b7684cc6d02bcd71.jpg',1,1685199592);
INSERT INTO `cy_album` VALUES (55,2,0,'风景','','uploads/img/20230527/a5ab7cb9deeaea67ceecfc21aa8f1d3b.jpg','uploads/thumb/20230527/1d6ba1f5e926f2d5a6233c5e3b9ce70c.jpg',1,1685199592);
INSERT INTO `cy_album` VALUES (56,2,0,'风景','','uploads/img/20230527/afc18ebefa66f25b6e24bc5daebba4af.jpg','uploads/thumb/20230527/7cbcdd6c9359905248982c1a0fbea4da.jpg',1,1685199592);
INSERT INTO `cy_album` VALUES (57,2,0,'风景','','uploads/img/20230527/e062aba66cc2a69de96c3e1c0c137d5f.jpg','uploads/thumb/20230527/be6d3a03bfee5bc1aec33d18a3a21686.jpg',1,1685199593);
INSERT INTO `cy_album` VALUES (58,2,0,'风景','','uploads/img/20230527/2987aeddc4596c6da214afab4e45f7be.jpg','uploads/thumb/20230527/16171c1b6ac88d47195d9b94c89164ad.jpg',1,1685199593);
INSERT INTO `cy_album` VALUES (59,2,0,'风景','','uploads/img/20230527/1f61a9610dd5631c4fda311fa065a405.jpg','uploads/thumb/20230527/3890e3d41028b5ceddebf351e4affac9.jpg',1,1685199593);
INSERT INTO `cy_album` VALUES (60,2,0,'风景','','uploads/img/20230527/56696b126adbf7495f89f341c6dc6828.jpg','uploads/thumb/20230527/4a8e283eb247dc59bc9880db9e8527eb.jpg',1,1685199594);
INSERT INTO `cy_album` VALUES (69,2,0,'风景','','uploads/img/20230527/31835a5e36923a41074d508057c5ca58.jpg','uploads/thumb/20230527/cd1bf7bb7a17f0a1d0951f43434ba838.jpg',1,1685199596);
INSERT INTO `cy_album` VALUES (70,2,0,'风景','','uploads/img/20230527/b032bae3aacfdc669d21efd167cfc836.jpg','uploads/thumb/20230527/28504665350955c9aa87f46ab5609d30.jpg',1,1685199597);
INSERT INTO `cy_album` VALUES (71,2,0,'风景','','uploads/img/20230527/8edd009f124914fc66fba4a73c221baa.jpg','uploads/thumb/20230527/29fc2a9be2131f09c7d131b8539fc55f.jpg',1,1685199597);
INSERT INTO `cy_album` VALUES (72,2,0,'风景','','uploads/img/20230527/071bc7da29812c8d81f352b76b67d590.jpg','uploads/thumb/20230527/38f2f232f41e71e9f8f95ef77f9a7c7c.jpg',1,1685199597);
INSERT INTO `cy_album` VALUES (73,2,0,'风景','','uploads/img/20230527/7fc990d2799888f55f679291dae99027.jpg','uploads/thumb/20230527/b8a7a8d2b626c7f57229abbdb48d9767.jpg',1,1685199598);
INSERT INTO `cy_album` VALUES (74,2,0,'风景','','uploads/img/20230527/0f65b36273cf4019ee6350b87d3bd259.jpg','uploads/thumb/20230527/a701aa972882dfc52db0f41b3067aede.jpg',1,1685199598);
INSERT INTO `cy_album` VALUES (75,2,0,'mmm','','uploads/img/20230529/21db3be12131da413574e8649cd84d33.jpg','uploads/thumb/20230529/13ed1afd8a9f8ed35e62d652bf7a518d.jpg',1,1685353923);
INSERT INTO `cy_album` VALUES (76,2,0,'mmm','','uploads/img/20230529/a2544804bb7cb12c5c888810ea63b779.jpg','uploads/thumb/20230529/eefe08fe52f94a2aeea5774634e44cfb.jpg',1,1685353923);
INSERT INTO `cy_album` VALUES (77,2,0,'mmm','','uploads/img/20230529/7760988178590f5300b7a6cba0ddb374.jpg','uploads/thumb/20230529/5f5176c197c4fd2871fa13367453ac39.jpg',1,1685353923);
INSERT INTO `cy_album` VALUES (78,2,0,'mmm','','uploads/img/20230529/6a317bb233da0e261b8896afefde9ef5.jpg','uploads/thumb/20230529/25ae95c0d5afe98ca548874b3accdbe2.jpg',1,1685353924);
INSERT INTO `cy_album` VALUES (79,2,0,'mmm','','uploads/img/20230529/4290f3c9f710892685e805b1258ad30b.jpg','uploads/thumb/20230529/6d0259e2d23f6e10364895b6c0aa3b6b.jpg',1,1685353924);
INSERT INTO `cy_album` VALUES (80,2,0,'mmm','','uploads/img/20230529/2a1881261dccf5679c93df0fce113787.jpg','uploads/thumb/20230529/78b87ad47cb5b7a233d35add4a7eda6b.jpg',1,1685353924);
INSERT INTO `cy_album` VALUES (81,1,0,'美女','','uploads/img/20230529/424b5b28eab677fe7b9f65ab9ae86810.jpg','uploads/thumb/20230529/5c17eafe79714f8b959c04e901786a83.jpg',1,1685365998);
INSERT INTO `cy_album` VALUES (82,1,0,'美女','','uploads/img/20230529/e5f9ad0d47681ab1990704fbe008e1ba.jpg','uploads/thumb/20230529/113910624c2e4d667d85e363fe392fa9.jpg',1,1685365998);
INSERT INTO `cy_album` VALUES (83,1,0,'dddf','','uploads/img/20230607/69a4aee08fb3fd511382013c7aefe39f.jpg','uploads/thumb/20230607/59467180b1c807d9682230429ed8f767.jpg',1,1686133008);
INSERT INTO `cy_album` VALUES (84,1,0,'dddf','','uploads/img/20230607/b1bc3daa1d40a5a95bff75f87fa5a7e0.jpg','uploads/thumb/20230607/454d355b5bc836631763c915eac20e61.jpg',1,1686133008);
INSERT INTO `cy_album` VALUES (85,1,0,'dddf','','uploads/img/20230607/2692718e7ef83e3185490c6318c62e02.jpg','uploads/thumb/20230607/609943bdf0e46a74af399bfb047d85aa.jpg',1,1686133008);
INSERT INTO `cy_album` VALUES (86,1,0,'dddf','','uploads/img/20230607/d67083034ea0004769811f350f59c2ab.jpg','uploads/thumb/20230607/515792e9b340c4e7fb1e6ff8e2b265c1.jpg',1,1686133008);
INSERT INTO `cy_album` VALUES (87,1,0,'dddf','','uploads/img/20230607/47683eb2b1f6636e4554841d8835a3c1.jpg','uploads/thumb/20230607/54d731970808c2e45a992959c3bc6d6b.jpg',1,1686133008);
INSERT INTO `cy_album` VALUES (90,2,0,'fasdfa','fasfasdf','uploads/images/202401/6596731b76568.jpg','uploads/thumb/202401/202401046596731b9bf89.jpeg',1,1704358683);
INSERT INTO `cy_album` VALUES (91,1,0,'fasdfasdf','asfasdfsadf','uploads/images/202401/65967364a06fe.jpg','uploads/thumb/202401/2024010465967364db3df.jpeg',1,1704358756);
